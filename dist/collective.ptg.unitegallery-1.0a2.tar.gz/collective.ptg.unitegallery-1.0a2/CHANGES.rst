Changelog
=========

1.0a2
------------------
- Fix wrong attribute in unitegallery.pt [Martronic-SA]
- Added some more options

1.0a1 (unreleased)
------------------

- Initial release.
  [Martronic-SA]
