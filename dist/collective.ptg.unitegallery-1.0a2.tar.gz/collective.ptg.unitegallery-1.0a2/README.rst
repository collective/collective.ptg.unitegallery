==============================================================================
collective.ptg.unitegallery
==============================================================================


Features
--------

- Advanced implementation of unite gallery into Plone using collective.plonetruegallery
Some of the options are still missing, feel free to fork and merge.


Examples
--------

http://unitegallery.net/


Documentation
-------------

Full documentation for end users can be found in the "docs" folder.


Translations
------------

This product has not been translated yet


Installation
------------

Install collective.ptg.unitegallery by adding it to your buildout::

    [buildout]

    ...

    eggs =
        collective.ptg.unitegallery


and then running ``bin/buildout``


Contribute
----------

- Issue Tracker: https://github.com/collective/collective.ptg.unitegallery/issues
- Source Code: https://github.com/collective/collective.ptg.unitegallery
- Documentation: https://docs.plone.org/foo/bar


Support
-------

If you are having issues, please let us know.


License
-------

The project is licensed under the GPLv2.
