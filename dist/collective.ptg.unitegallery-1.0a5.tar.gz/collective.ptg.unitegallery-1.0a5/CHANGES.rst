Changelog
=========
1.0a5
-----
- Fix wrong None.css link when skin is not set.

1.0a4
-----
- changed position of off('touchstart') after gallery initialisation

1.0a3
-----
- Use collective.js.unitegallery
- added off('touchstart') to fix scroll on mobile devices (needs furher investigations)

1.0a2
------------------
- Fix wrong attribute in unitegallery.pt [Martronic-SA]
- Added some more options

1.0a1 (unreleased)
------------------

- Initial release.
  [Martronic-SA]
